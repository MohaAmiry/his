package com.example.his

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
