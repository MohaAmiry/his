mixin StringManager {
  static const String emptyStr = "";
  static const String email = "Email";
  static const String password = "Password";
  static const String forgotPassword = "Forgot Password";
  static const String login = "Login";
  static const String register = "Register";
}
