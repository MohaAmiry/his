enum UserType { customer, company, admin }

enum QuoteStatus { pending, accepted, done, rejected }
