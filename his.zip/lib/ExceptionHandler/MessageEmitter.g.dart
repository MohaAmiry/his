// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'MessageEmitter.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$messageEmitterHash() => r'54b5b0ddc1302a87684917d4a97d885ed4909940';

/// See also [MessageEmitter].
@ProviderFor(MessageEmitter)
final messageEmitterProvider =
    AutoDisposeNotifierProvider<MessageEmitter, Message?>.internal(
  MessageEmitter.new,
  name: r'messageEmitterProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$messageEmitterHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MessageEmitter = AutoDisposeNotifier<Message?>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
