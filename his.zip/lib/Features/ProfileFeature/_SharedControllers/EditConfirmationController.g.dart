// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'EditConfirmationController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$editConfirmationControllerHash() =>
    r'89555c9450e97e99175b11bec8e17eb9a266bb50';

/// See also [EditConfirmationController].
@ProviderFor(EditConfirmationController)
final editConfirmationControllerProvider =
    AutoDisposeAsyncNotifierProvider<EditConfirmationController, bool>.internal(
  EditConfirmationController.new,
  name: r'editConfirmationControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$editConfirmationControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EditConfirmationController = AutoDisposeAsyncNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
