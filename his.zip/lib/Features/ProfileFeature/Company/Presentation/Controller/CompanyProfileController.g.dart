// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'CompanyProfileController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$companyProfileControllerHash() =>
    r'1bc2d170dbf4ff0e5cb0b30ebbf9bbf7775515e0';

/// See also [CompanyProfileController].
@ProviderFor(CompanyProfileController)
final companyProfileControllerProvider = AutoDisposeAsyncNotifierProvider<
    CompanyProfileController, CompanyResponseModel>.internal(
  CompanyProfileController.new,
  name: r'companyProfileControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$companyProfileControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CompanyProfileController
    = AutoDisposeAsyncNotifier<CompanyResponseModel>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
