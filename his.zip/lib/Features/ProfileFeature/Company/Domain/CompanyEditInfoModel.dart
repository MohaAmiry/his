typedef CompanyEditBusinessInfoModel = ({String name, String phoneNumber});
