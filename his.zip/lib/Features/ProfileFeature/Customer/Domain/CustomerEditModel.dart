typedef CustomerEditModel = ({String name, String phoneNumber});
