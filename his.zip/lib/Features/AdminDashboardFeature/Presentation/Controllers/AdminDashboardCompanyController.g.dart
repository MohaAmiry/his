// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'AdminDashboardCompanyController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$adminDashboardCompanyControllerHash() =>
    r'b0e089cb2e8347e74ce906a211eac5a8a1bbb462';

/// See also [AdminDashboardCompanyController].
@ProviderFor(AdminDashboardCompanyController)
final adminDashboardCompanyControllerProvider =
    AutoDisposeAsyncNotifierProvider<AdminDashboardCompanyController,
        List<AdminDashboardCompanyModel>>.internal(
  AdminDashboardCompanyController.new,
  name: r'adminDashboardCompanyControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$adminDashboardCompanyControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AdminDashboardCompanyController
    = AutoDisposeAsyncNotifier<List<AdminDashboardCompanyModel>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
