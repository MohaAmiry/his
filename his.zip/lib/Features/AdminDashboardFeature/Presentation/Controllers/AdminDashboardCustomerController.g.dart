// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'AdminDashboardCustomerController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$adminDashboardCustomerControllerHash() =>
    r'6f27388c8307066cb860865a4a4ec2f3b77da42f';

/// See also [AdminDashboardCustomerController].
@ProviderFor(AdminDashboardCustomerController)
final adminDashboardCustomerControllerProvider =
    AutoDisposeAsyncNotifierProvider<AdminDashboardCustomerController,
        List<AdminDashboardCustomerModel>>.internal(
  AdminDashboardCustomerController.new,
  name: r'adminDashboardCustomerControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$adminDashboardCustomerControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AdminDashboardCustomerController
    = AutoDisposeAsyncNotifier<List<AdminDashboardCustomerModel>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
