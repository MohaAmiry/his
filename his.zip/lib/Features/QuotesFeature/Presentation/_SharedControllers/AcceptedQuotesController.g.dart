// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'AcceptedQuotesController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$acceptedQuotesControllerHash() =>
    r'f878c92062bf988cd904f5a9a548bf9df3f1eb86';

/// See also [AcceptedQuotesController].
@ProviderFor(AcceptedQuotesController)
final acceptedQuotesControllerProvider = AutoDisposeAsyncNotifierProvider<
    AcceptedQuotesController, IList<QuoteResponseModel>>.internal(
  AcceptedQuotesController.new,
  name: r'acceptedQuotesControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$acceptedQuotesControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AcceptedQuotesController
    = AutoDisposeAsyncNotifier<IList<QuoteResponseModel>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
