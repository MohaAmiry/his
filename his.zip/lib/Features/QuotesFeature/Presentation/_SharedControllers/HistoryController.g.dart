// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'HistoryController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$historyControllerHash() => r'b5eca092ec583b9e04b07f6ac64db0d60e26733d';

/// See also [HistoryController].
@ProviderFor(HistoryController)
final historyControllerProvider = AutoDisposeAsyncNotifierProvider<
    HistoryController, IList<QuoteResponseModel>>.internal(
  HistoryController.new,
  name: r'historyControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$historyControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$HistoryController
    = AutoDisposeAsyncNotifier<IList<QuoteResponseModel>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
