// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'PendingQuotesController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$pendingQuotesControllerHash() =>
    r'e8c8c28a9d7c794a5aaff1a20676af12ca9685ad';

/// See also [PendingQuotesController].
@ProviderFor(PendingQuotesController)
final pendingQuotesControllerProvider = AutoDisposeAsyncNotifierProvider<
    PendingQuotesController, IList<QuoteResponseModel>>.internal(
  PendingQuotesController.new,
  name: r'pendingQuotesControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$pendingQuotesControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PendingQuotesController
    = AutoDisposeAsyncNotifier<IList<QuoteResponseModel>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
