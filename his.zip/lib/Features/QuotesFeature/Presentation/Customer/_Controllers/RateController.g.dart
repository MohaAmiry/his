// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'RateController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$rateControllerHash() => r'3025eeec1d2e4f86233233630fe7e110c54884b3';

/// See also [RateController].
@ProviderFor(RateController)
final rateControllerProvider =
    AutoDisposeAsyncNotifierProvider<RateController, bool?>.internal(
  RateController.new,
  name: r'rateControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$rateControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RateController = AutoDisposeAsyncNotifier<bool?>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
