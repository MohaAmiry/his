// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'AddQuoteEntityController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$addQuoteEntityControllerHash() =>
    r'8c0f6a994757337c1911ae6944806d0ae6639824';

/// See also [AddQuoteEntityController].
@ProviderFor(AddQuoteEntityController)
final addQuoteEntityControllerProvider = AutoDisposeNotifierProvider<
    AddQuoteEntityController, AddQuoteEntity>.internal(
  AddQuoteEntityController.new,
  name: r'addQuoteEntityControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$addQuoteEntityControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AddQuoteEntityController = AutoDisposeNotifier<AddQuoteEntity>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
