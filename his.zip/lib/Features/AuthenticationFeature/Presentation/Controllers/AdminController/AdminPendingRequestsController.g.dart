// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'AdminPendingRequestsController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$adminPendingRequestsControllerHash() =>
    r'3974dc167028f136b141149daa475bcee71f29e3';

/// See also [AdminPendingRequestsController].
@ProviderFor(AdminPendingRequestsController)
final adminPendingRequestsControllerProvider = AutoDisposeAsyncNotifierProvider<
    AdminPendingRequestsController, IList<CompanyResponseModel>>.internal(
  AdminPendingRequestsController.new,
  name: r'adminPendingRequestsControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$adminPendingRequestsControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$AdminPendingRequestsController
    = AutoDisposeAsyncNotifier<IList<CompanyResponseModel>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
