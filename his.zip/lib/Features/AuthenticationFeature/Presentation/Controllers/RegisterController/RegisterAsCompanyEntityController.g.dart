// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'RegisterAsCompanyEntityController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$registerAsCompanyEntityControllerHash() =>
    r'9352fd9f8f3fef20cac715bec5af520e6c13a903';

/// See also [RegisterAsCompanyEntityController].
@ProviderFor(RegisterAsCompanyEntityController)
final registerAsCompanyEntityControllerProvider = AutoDisposeNotifierProvider<
    RegisterAsCompanyEntityController, RegisterAsCompanyEntity>.internal(
  RegisterAsCompanyEntityController.new,
  name: r'registerAsCompanyEntityControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$registerAsCompanyEntityControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RegisterAsCompanyEntityController
    = AutoDisposeNotifier<RegisterAsCompanyEntity>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
