// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'RegisterAsCustomerEntityController.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$registerAsCustomerEntityControllerHash() =>
    r'27271703d20486ec999d73999915842395339d71';

/// See also [RegisterAsCustomerEntityController].
@ProviderFor(RegisterAsCustomerEntityController)
final registerAsCustomerEntityControllerProvider = AutoDisposeNotifierProvider<
    RegisterAsCustomerEntityController, RegisterAsCustomerEntity>.internal(
  RegisterAsCustomerEntityController.new,
  name: r'registerAsCustomerEntityControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$registerAsCustomerEntityControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$RegisterAsCustomerEntityController
    = AutoDisposeNotifier<RegisterAsCustomerEntity>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
